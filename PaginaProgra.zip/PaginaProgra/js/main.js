function clicked(){
	var user = document.getElementById("username");
	var pass = document.getElementById("password");

	var coruser ="fernando";
	var corpass  ="123";

	if(user.value == coruser){
		if(pass.value == corpass){
			window.alert(" bienvenido fernando " + user.value);
			window.open("web/index.html");

		} 

			else{
			window.alert("esta incorrecto tu usuario o contraseña intentalo de nuevo");
			}

	} 

		else{
		window.alert("esta incorrecto tu usuario o contraseña intentalo de nuevo");

		}

}